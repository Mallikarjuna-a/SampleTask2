//
//  KeyCell.swift
//  SampleTask2
//
//  Created by MALLI on 22/04/20.
//  Copyright © 2020 MALLI. All rights reserved.
//

import UIKit

class KeyCell: UICollectionViewCell {
    
//    @IBOutlet weak var digitsLabel:UILabel!
    
    @IBOutlet weak var digitsLabel: UILabel!
    
}
